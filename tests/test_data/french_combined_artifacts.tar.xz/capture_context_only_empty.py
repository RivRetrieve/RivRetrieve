"""Capture genuine unrestricted-provider empty public selection from baseline."""
import hashlib
import json
from pathlib import Path
import rivretrieve as rr
root = Path.cwd()
out = root / ".worktrees/evidence/effort-310-baseline"
attestation = json.loads((out / "attestation.json").read_text())
for name, metadata in attestation["files"].items():
    assert hashlib.sha256((out / name).read_bytes()).hexdigest() == metadata["sha256"]
selection = rr.find(station="07374000", quantity="temperature", statistic="max")
assert not selection.scope.provider_ids
assert not selection.series
assert all(item.provider_id != "fr_hubeau" for item in selection.known_series)
assert any(item.header.provider_id == "fr_hubeau" for item in selection.acquisition_provenance)
target = out / "context-only-empty-selection.bundle"
target.write_bytes(rr.to_bundle(selection))
restored = rr.from_bundle(target.read_bytes())
assert not restored.scope.provider_ids and not restored.series
for path in (target, out / "capture_context_only_empty.py"):
    content = path.read_bytes()
    attestation["files"][str(path.relative_to(out))] = {"sha256":hashlib.sha256(content).hexdigest(),"byte_count":len(content)}
attestation["context_only_empty_capture"] = {"producer_revision":"fd55eee9d32a278b895bc61487452d43564eaed4", "command":"uv run python .worktrees/evidence/effort-310-baseline/capture_context_only_empty.py", "public_call": "rr.find(station='07374000', quantity='temperature', statistic='max')", "note":"Unknown station filters raise UnknownStationError; known USGS station and incompatible quantity/statistic produce authentic empty selection without provider restriction"}
(out / "attestation.json").write_text(json.dumps(attestation,indent=2)+"\n")
print("Captured unrestricted empty selection with preserved French catalogue evidence")
