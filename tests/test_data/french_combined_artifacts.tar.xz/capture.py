"""Capture actual baseline public outputs using unchanged saved source transport recordings."""
import hashlib
import json
import os
from pathlib import Path
import rivretrieve as rr
import rivretrieve._internal.discovery as discovery
from rivretrieve._internal.recordings import ReplayTransport, read_recording

root = Path.cwd()
out = root / ".worktrees/evidence/effort-310-baseline"
os.environ["RIVRETRIEVE_CACHE_DIR"] = str(out / "cache")
data = root / "tests/test_data"
scopes = {
    "combined-station-selection": rr.find(provider="fr_hubeau", station="1232000101"),
    "empty-selection": rr.find(provider="fr_hubeau", station="01001336", quantity="stage"),
}
cases = (
    ("hydroportail", "1232000101", {"quantity":"discharge", "statistic":"instantaneous"}, "2026-06-01", "2026-06-02", "fr_hydroportail_station_Q_padded.recording.json"),
    ("hubeau-daily", "1011000101", {"quantity":"discharge", "frequency":"daily", "statistic":"mean"}, "2025-01-03", "2025-01-03", "fr_hubeau_1011000101_QmnJ_padded.recording.json"),
)
for name, station, predicates, start, end, recording in cases:
    selection = rr.find(provider="fr_hubeau", station=station, **predicates)
    scopes[name + "-selection"] = selection
    for receipts in (False, True):
        replay = ReplayTransport((read_recording(data / recording),))
        discovery.HttpClient = lambda: replay
        result = rr.fetch(selection, start=start, end=end, cache="refresh", receipts=receipts, on_issue="raise")
        target = out / f"{name}-result-receipts-{receipts}.bundle"
        target.write_bytes(rr.to_bundle(result))
        assert rr.from_bundle(target.read_bytes()).source_series == result.source_series
for name, selection in scopes.items():
    target = out / (name + ".bundle")
    target.write_bytes(rr.to_bundle(selection))
    rr.from_bundle(target.read_bytes())
status = rr.cache_status("fr_hubeau")
assert status.format_version == 7
files = {str(p.relative_to(out)): {"sha256":hashlib.sha256(p.read_bytes()).hexdigest(), "byte_count":p.stat().st_size} for p in sorted(out.rglob("*")) if p.is_file() and p.name not in {"attestation.json", "capture.log"}}
(out / "attestation.json").write_text(json.dumps({"producer_revision":"fd55eee9d32a278b895bc61487452d43564eaed4", "command":"uv run python .worktrees/evidence/effort-310-baseline/capture.py", "purpose":"Authentic pre-split current-format combined fr_hubeau public outputs; no relabelled source material", "store_format":7,"bundle_format":2,"recordings":[case[-1] for case in cases],"files":files},indent=2)+"\n")
print(json.dumps({"files":len(files),"store_format":status.format_version}))
