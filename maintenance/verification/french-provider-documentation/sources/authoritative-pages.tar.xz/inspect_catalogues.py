import json
import polars as pl
from pathlib import Path
import rivretrieve as rr
root=Path.cwd()
for provider in ("fr_hubeau","fr_hydroportail"):
 d=root/"src/rivretrieve/_internal/providers"/provider/"catalogue"
 print(provider,"station rows",pl.read_parquet(d/"stations.parquet").height)
 n=pl.read_parquet(d/"native.parquet")
 if "source_endpoint" in n.columns: print(n.group_by("source_endpoint").len())
 print("provider metadata",(d/"provider.json").read_text())
 print("products",pl.read_parquet(d/"products.parquet").select("product_id","unit","period_type","period_anchor").to_dicts())
 s=rr.find(provider=provider,station="Y251002001",quantity="discharge")
 print("public series",rr.series(s))
