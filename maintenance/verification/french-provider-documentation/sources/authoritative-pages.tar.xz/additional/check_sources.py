import concurrent.futures, datetime, hashlib, json, pathlib, urllib.request
urls=['https://hydro.eaufrance.fr/stationhydro/Y251002001/series', 'https://hydro.eaufrance.fr/build/4210.e6896d9b.js', 'https://hydro.eaufrance.fr/build/5621.4ab47ec9.js', 'https://www.etalab.gouv.fr/licence-ouverte-open-licence', 'https://hubeau.eaufrance.fr/page/a-propos']
out=pathlib.Path(__file__).parent
def get(item):
 i,url=item
 record={"url":url,"checked_utc":datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={"User-Agent":"Mozilla/5.0"}),timeout=45) as response:
   body=response.read(); filename=f"{i:02d}.html"; (out/filename).write_bytes(body)
   record.update(status=response.status,final_url=response.url,file=filename,sha256=hashlib.sha256(body).hexdigest())
 except Exception as exc: record["error"]=repr(exc)
 return record
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool: results=list(pool.map(get,enumerate(urls)))
(out/"checks.json").write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
