import concurrent.futures, datetime, hashlib, json, pathlib, urllib.request
urls=['https://hubeau.eaufrance.fr/page/api-hydrometrie', 'https://hubeau.eaufrance.fr/page/api-temperature-continu', 'https://hydro.eaufrance.fr/aide/accueil', 'https://hubeau.eaufrance.fr/', 'https://hydro.eaufrance.fr/', 'https://hydro.eaufrance.fr/glossaire', 'https://www.etalab.gouv.fr/licence-ouverte-open-licence.', 'https://www.data.gouv.fr/pages/legal/licences/etalab-2.0', 'https://hubeau.eaufrance.fr/page/conditions-generales', 'https://hubeau.eaufrance.fr/mentions-legales-credits', 'https://hydro.eaufrance.fr/edito/mentions-legales', 'https://hydro.eaufrance.fr/edito/a-propos-dhydroportail', 'https://hydro.eaufrance.fr/aide/la-station-hydrometrique', 'https://hydro.eaufrance.fr/aide/le-site-hydrometrique', 'https://hydro.eaufrance.fr/aide/les-series-de-mesures', 'https://hydro.eaufrance.fr/faq']
out=pathlib.Path(__file__).parent
def get(item):
 i,url=item
 record={"url":url,"checked_utc":datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={"User-Agent":"Mozilla/5.0"}),timeout=45) as response:
   body=response.read(); filename=f"{i:02d}.html"; (out/filename).write_bytes(body)
   record.update(status=response.status,final_url=response.url,file=filename,sha256=hashlib.sha256(body).hexdigest())
 except Exception as exc: record["error"]=repr(exc)
 return record
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool: results=list(pool.map(get,enumerate(urls)))
(out/"checks.json").write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
