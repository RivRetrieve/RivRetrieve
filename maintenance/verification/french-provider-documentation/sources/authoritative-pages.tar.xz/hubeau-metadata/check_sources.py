import concurrent.futures, datetime, hashlib, json, pathlib, urllib.request
urls=['https://hubeau.eaufrance.fr/api/v2/hydrometrie/api-docs', 'https://hubeau.eaufrance.fr/api/v2/hydrometrie/obs_elab?code_entite=Y251002001&date_debut_obs_elab=2024-01-01&date_fin_obs_elab=2024-01-01&grandeur_hydro_elab=QmnJ&size=1']
out=pathlib.Path(__file__).parent
def get(item):
 i,url=item
 record={"url":url,"checked_utc":datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={"User-Agent":"Mozilla/5.0"}),timeout=45) as response:
   body=response.read(); filename=f"{i:02d}.html"; (out/filename).write_bytes(body)
   record.update(status=response.status,final_url=response.url,file=filename,sha256=hashlib.sha256(body).hexdigest())
 except Exception as exc: record["error"]=repr(exc)
 return record
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool: results=list(pool.map(get,enumerate(urls)))
(out/"checks.json").write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
